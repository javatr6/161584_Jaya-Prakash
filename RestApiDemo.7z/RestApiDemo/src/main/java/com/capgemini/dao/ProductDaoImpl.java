package com.capgemini.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.capgemini.model.Product;

public class ProductDaoImpl implements IproductDao{

	private static List<Product> products=dummyDB();

	public List<Product> getAllProducts() {

		return products;
	}

	private static List<Product> dummyDB() {
		List<Product> products=new ArrayList<Product>();
		products.add(new Product(1, "Samsung On7 pro"));
		products.add(new Product(3451, "Lenovo"));
		products.add(new Product(543223, "iPhone x"));
		products.add(new Product(565, "One plus 6"));
		products.add(new Product(1001, "Nokia 7"));

		return products;
	}

	public List<Product> removeProduct(int productId) {

		Iterator<Product> iterator=products.iterator();
		while(iterator.hasNext()) {
			Product product=iterator.next();
			if(product.getProductId()==productId) {
				iterator.remove();
				break;
			}
		}

		return products;
	}

	public List<Product> addnewProduct(int productId, String productName) {

		products.add(new Product(productId,productName));

		return products;
	}

	public Product getProduct(int productId) {
		Iterator<Product> iterator=products.iterator();
		while(iterator.hasNext()) {
			Product product=iterator.next();
			if(product.getProductId()==productId) {
				return product;
			}
		}
		return null;
	}
	public List<Product> updateProducts(int productId, String productName) {
		Iterator<Product> iterator = products.iterator();
		while(iterator.hasNext()) {
			Product product=iterator.next();
			if(product.getProductId()==productId) {
				product.setProductName(productName);
				break;

			}
		}
		return products;

	}   

}
