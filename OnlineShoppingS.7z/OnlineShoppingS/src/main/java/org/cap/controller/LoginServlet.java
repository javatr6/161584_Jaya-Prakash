package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.model.LoginBean;
import org.cap.service.ILoginService;
import org.cap.service.LoginServiceImpl;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String UserName=request.getParameter("UserName");
		String Password=request.getParameter("PassWord");
		LoginBean loginBean=new LoginBean(UserName,Password);
		
		ILoginService iLoginService = new LoginServiceImpl();

        PrintWriter pw=response.getWriter();
					
		if(iLoginService.isValidLogin(loginBean)) {
			response.sendRedirect("pages/sucess.html");
		}else {
			String message="Please Provide Valid Details!!";
			request.getRequestDispatcher("/index.html").include(request, response);
			pw.println(message);
		}
		
	
	}
}


