package org.cap.model;

public class LoginBean {

	private String UserName;
	private String Password;
	
	public LoginBean() {
		
	}

	public LoginBean(String userName, String password) {
		super();
		UserName = userName;
		Password = password;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	@Override
	public String toString() {
		return "LoginBean [UserName=" + UserName + ", Password=" + Password + "]";
	}
	

}
