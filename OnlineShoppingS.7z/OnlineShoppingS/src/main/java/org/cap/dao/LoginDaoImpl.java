package org.cap.dao;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.cap.model.LoginBean;

public class LoginDaoImpl implements ILoginDao {

	@Override
	public Boolean isValidLogin(LoginBean loginBean) {
		
		String sql="select * from adminLogin where UserName=?"
				+ "and UserPassword=?";
		
		
		try(
			PreparedStatement pst=getmySqlDBConnection().prepareStatement(sql);	
			){
			pst.setString(1, loginBean.getUserName());
			pst.setString(2, loginBean.getPassword());
			ResultSet rs=pst.executeQuery();
			
			if(rs.next()) {
				return true;
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
private Connection getmySqlDBConnection() {
	
	Connection connection=null;
	 
	try {
		Class.forName("com.mysql.jdbc.Driver");
		connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/capdb","root","India123");
		return connection;
	}catch(SQLException e) {
		e.printStackTrace();
	}catch (ClassNotFoundException e) {	
		e.printStackTrace();
	}
	return null;	
	}

}
