package org.cap.service;

import org.cap.model.LoginBean;

public interface ILoginService {

	public Boolean isValidLogin(LoginBean loginBean);
	
}
