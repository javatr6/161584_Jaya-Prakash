package org.cap.service;

import org.cap.dao.ILoginDao;
import org.cap.dao.LoginDaoImpl;
import org.cap.model.LoginBean;


public class LoginServiceImpl implements  ILoginService  {

	ILoginDao loginDao=new LoginDaoImpl();
	@Override
	public Boolean isValidLogin(LoginBean loginBean) {
		if(loginDao.isValidLogin(loginBean)) {
			return true;
		}
		return false;
	}
	
}
