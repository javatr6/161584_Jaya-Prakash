function validate() {

	flag=false;
	var UserName=f1.UserName.value;
	var UserPassword=f1.UserPassWord.value;
	if(UserName=="" || UserName==null) {
		document.getElementById('error').innerHTML="*Please Enter your UserName";
		flag=false;
	}else if(UserPassword=="" || UserPassword==null) {
		document.getElementById('errpassword').innerHTML="*Please Enter your Password";
		flag=false;
	}else {
		flag=true;
	}
	return flag;
}