package com.capg.OneToOne;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Address {
	@Id
	@GeneratedValue
	private int addId;
	private String address;
	
	@OneToOne
	@JoinColumn(name="custIdFK")
	private Customer customer;


	public Address() {
		
	}
	
	
	public Address(String address, Customer customer) {
		super();
		this.address = address;
		this.customer = customer;
	}


	public Address(int addId, String address, Customer customer) {
		super();
		this.addId = addId;
		this.address = address;
		this.customer = customer;
	}


	public int getAddId() {
		return addId;
	}


	public void setAddId(int addId) {
		this.addId = addId;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public Customer getCustomer() {
		return customer;
	}


	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	@Override
	public String toString() {
		return "Address [addId=" + addId + ", address=" + address + ", customer=" + customer + "]";
	}

}
