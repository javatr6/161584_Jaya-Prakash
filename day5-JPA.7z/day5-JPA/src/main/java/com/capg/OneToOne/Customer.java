package com.capg.OneToOne;

import java.time.LocalDate;

import javax.annotation.processing.Generated;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Customer {
	@Id
	@GeneratedValue
	private Integer custId;
	private String fName;
	private String lName;
	private double regfees;
	
	public Customer() {
		
	}
	
	
	public Customer(String fName, String lName, double regfees) {
		super();
		this.fName = fName;
		this.lName = lName;
		this.regfees = regfees;
	}


	public Customer(Integer custId, String fName, String lName, double regfees) {
		super();
		this.custId = custId;
		this.fName = fName;
		this.lName = lName;
		this.regfees = regfees;
	}

	public Integer getCustId() {
		return custId;
	}

	public void setCustId(Integer custId) {
		this.custId = custId;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public double getRegfees() {
		return regfees;
	}

	public void setRegfees(double regfees) {
		this.regfees = regfees;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", fName=" + fName + ", lName=" + lName + ", regfees=" + regfees + "]";
	}
	
	
	
	

}
