package com.capg.OneToMany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestClass {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		Company company=entityManager.find(Company.class, 2);
		System.out.println(company.getCompanyId());
		System.out.println(company.getCompanyName());
		entityManager.persist(company);
		
		for(Employee employee:company.getEmployee()) {
			System.out.println(employee.getEmpId()+"--->"+employee.getEmpName());
		}
		transaction.commit();
		entityManager.close();
		
	}

}
