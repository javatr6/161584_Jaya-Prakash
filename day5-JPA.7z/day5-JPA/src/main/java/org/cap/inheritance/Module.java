package org.cap.inheritance;

import javax.persistence.Entity;

@Entity
public class Module extends Project {
	private String ModuleName;

	public Module() {
		
	}
	
	public Module(String moduleName) {
		super();
		ModuleName = moduleName;
	}

	public String getModuleName() {
		return ModuleName;
	}

	public void setModuleName(String moduleName) {
		ModuleName = moduleName;
	}

	@Override
	public String toString() {
		return "Module [ModuleName=" + ModuleName + "]";
	}

}
