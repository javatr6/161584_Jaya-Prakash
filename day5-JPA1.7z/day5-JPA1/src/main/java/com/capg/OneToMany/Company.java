package com.capg.OneToMany;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Company {
	@Id
	@GeneratedValue
	private int companyId;
	private String companyName;
	LocalDate date=LocalDate.now();
	
	@OneToMany(mappedBy="company",targetEntity=Employee.class, cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	private List<Employee> employee=new ArrayList<>();

	
	public Company() {
		
	}


	public Company(int companyId, String companyName, LocalDate date, List<Employee> employee) {
		super();
		this.companyId = companyId;
		this.companyName = companyName;
		this.date = date;
		this.employee = employee;
	}


	public int getCompanyId() {
		return companyId;
	}


	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}


	public String getCompanyName() {
		return companyName;
	}


	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}


	public LocalDate getDate() {
		return date;
	}


	public void setDate(LocalDate date) {
		this.date = date;
	}


	public List<Employee> getEmployee() {
		return employee;
	}


	public void setEmployee(List<Employee> employee) {
		this.employee = employee;
	}


	@Override
	public String toString() {
		return "Company [companyId=" + companyId + ", companyName=" + companyName + ", date=" + date + ", employee="
				+ employee + "]";
	}


	public Company(int companyId, String companyName, LocalDate date) {
		super();
		this.companyId = companyId;
		this.companyName = companyName;
		this.date = date;
	}

}
