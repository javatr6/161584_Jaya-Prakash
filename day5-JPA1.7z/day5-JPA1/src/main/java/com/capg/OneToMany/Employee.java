package com.capg.OneToMany;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Employee {
	@Id
    private int empId;
	private String empName;
	private int companyId;

			
	@ManyToOne
	@JoinColumn(name="companyFk")
	private Company company;

	public Employee() {
		
	}

	public Employee(String empName, int companyId, Company company) {
		super();
		this.empName = empName;
		this.companyId = companyId;
		this.company = company;
	}

	public Employee(int empId, String empName, int companyId, Company company) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.companyId = companyId;
		this.company = company;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", companyId=" + companyId + ", company=" + company
				+ "]";
	}

	
}
