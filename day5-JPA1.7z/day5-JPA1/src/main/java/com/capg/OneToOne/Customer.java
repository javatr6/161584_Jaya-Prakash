package com.capg.OneToOne;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Customer {
	@Id
	@GeneratedValue
	private int custId;
	private String firstName;
	private double registFee;
	private LocalDate date;
	
	public Customer() {
		
	}

	public Customer(int custId, String firstName, double registFee, LocalDate date) {
		super();
		this.custId = custId;
		this.firstName = firstName;
		this.registFee = registFee;
		this.date = date;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public double getRegistFee() {
		return registFee;
	}

	public void setRegistFee(double registFee) {
		this.registFee = registFee;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", firstName=" + firstName + ", registFee=" + registFee + ", date=" + date
				+ "]";
	}

	
}
