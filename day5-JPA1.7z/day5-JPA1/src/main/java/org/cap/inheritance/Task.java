package org.cap.inheritance;

import java.time.LocalDate;

import javax.persistence.Entity;

@Entity
public class Task extends Module {
	
	private String taskName;
	private LocalDate date=LocalDate.now();
	
	public Task() {
		
	}

	public Task(String taskName) {
		super();
		this.taskName = taskName;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	@Override
	public String toString() {
		return "Task [taskName=" + taskName + "]";
	}
	
	
	
	
	

}
