package com.cg.bp;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Mainclass {

	public static void main(String[] args) {
		EntityManagerFactory emf = 
        		Persistence.createEntityManagerFactory("jpademo");
        EntityManager emp = emf.createEntityManager();
        EntityTransaction transaction= emp.getTransaction();
        
     transaction.begin();
     Login login=new Login("tom","tom123");
     Login login1=new Login("joe","joe345");
     Login login2=new Login("jack","jack456");
      
     Busroute busroute=new Busroute();
     busroute.setRoutePath("MIPL Veerapuram Chengalpet");
     busroute.setRouteName("MIPL");
     busroute.setOccupied(15);
     busroute.setTotalSeats(40);
     busroute.setDiverName("john");
     busroute.setBusNo("TN4865");
     busroute.setTotalKm(50);
        
        emp.persist(login);
        emp.persist(login1);
        emp.persist(login2);
        emp.persist(busroute);
        transaction.commit();
        emp.close();

	}
}
